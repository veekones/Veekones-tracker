
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCCThTgdJ6fWHTNXB7PkICqTgaXZuwPc_E",
  authDomain: "veekones-tracker-85fd9.firebaseapp.com",
  projectId: "veekones-tracker-85fd9",
  storageBucket: "veekones-tracker-85fd9.firebasestorage.app",
  messagingSenderId: "1018949161799",
  appId: "1:1018949161799:web:b5401ad8797a6be0417262"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
